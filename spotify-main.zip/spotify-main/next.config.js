/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ["meggkopiinwpefsqnqac.supabase.co"],
  },
};

module.exports = nextConfig;
